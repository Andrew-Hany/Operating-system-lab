in order to run
you need to write:  
                    make
then write: 
                insmod lab3.ko mystring = "" myint= 11
then: 
                dmesg
then:   
                rmmode  lab3.ko
then: 
                dmesg          
            